<?php
namespace omnimaga\OmnomIRC;

class ext extends \phpbb\extension\base
{
	function enable_step($old_state)
	{
		return parent::enable_step($old_state);
	}
}
