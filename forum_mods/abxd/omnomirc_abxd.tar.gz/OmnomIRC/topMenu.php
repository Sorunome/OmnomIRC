<?php $navigation->add(new PipeMenuLinkEntry(__("IRC"), "irc", "", "", "quote-right")); ?>
