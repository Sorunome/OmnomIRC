<?php
/* This is a automatically generated config-file by OmnomIRC, please use the admin pannel to edit it! */
header("Location:index.php");
exit;
?>
{"installed":false,"sigKey":"","hook":"generic","network":1,"oircUrl":""}
